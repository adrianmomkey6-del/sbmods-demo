# SB MODS V4 · DEMO

App Android de **simulación visual** con ventana flotante real. 
**No se conecta a ningún juego, no tiene permiso de internet y no modifica nada fuera de sí misma.**
La etiqueta `SIMULACIÓN · NO CONECTADO AL JUEGO` es fija en la ventana y el botón flotante dice `DEMO`.

## Qué hace (todo verificado solo por lectura de código, ver "Estado de pruebas")

- Botón flotante "SB" arrastrable (con etiqueta DEMO).
- Al tocarlo se abre la ventana: se mueve por la pantalla, se minimiza (vuelve al botón), se agranda/achica (⤢) y se cierra (✕).
- Secciones: INICIO, DINERO, MONEDAS, CARROS, CAMBIAR ID, TIENDA VIP, DESBLOQUEAR, CUENTAS, AJUSTES.
- Las acciones son simulaciones con barra de progreso y datos ficticios ("Coche de ejemplo A", "cuenta_ejemplo_1").
- AJUSTES sí son reales: tamaño, transparencia (mínimo 40 %) y restablecer posición. Se guardan.
- Servicio en primer plano con notificación y botón "Cerrar".
- Permisos: superposición (SYSTEM_ALERT_WINDOW), servicio en primer plano y notificaciones. Nada más.

## Cómo compilar el APK

### Opción A: GitHub Actions (gratis, sin instalar nada)
1. Crea una cuenta en github.com y un repositorio nuevo (privado está bien).
2. Sube todo el contenido de esta carpeta (incluida `.github/`).
3. Ve a la pestaña **Actions → Build APK → Run workflow**.
4. Cuando termine, descarga el artefacto `SB-MODS-V4-DEMO-apk` (trae `app-debug.apk`).

### Opción B: Android Studio (PC)
1. Abre la carpeta como proyecto, deja que sincronice Gradle.
2. Build → Build APK(s). El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Cómo instalar y probar en el Note 10 (Android 12)
1. Instala el APK (permite "instalar apps desconocidas" para tu gestor de archivos).
2. Abre SB MODS V4 · DEMO → paso 1: concede "Mostrar sobre otras apps".
3. Paso 3: ACTIVAR VENTANA FLOTANTE. La app se manda al fondo.
4. Abre otra app: debe verse el botón flotante "SB · DEMO". Tócalo para abrir el panel.

## Cambiar el nombre (V4 / SVMods)
- Nombre bajo el ícono: `app/src/main/res/values/strings.xml`.
- Texto del panel: busca `"SB MODS V4"` en `OverlayService.kt` y `MainActivity.kt`.

## Estado de pruebas (honesto)
- **No se compiló ni se ejecutó** en el entorno donde se escribió (sin Android SDK ni red).
- Solo se revisó la sintaxis a mano (llaves y paréntesis balanceados).
- Pueden aparecer errores de compilación o de comportamiento al primer intento. Si pasa,
  copia el mensaje de error completo y se corrige.
- Pendiente de comprobar en el teléfono: permiso de superposición, arrastre, minimizar,
  expandir, cierre desde la notificación y comportamiento sobre otras apps.
