package com.sbmods.demo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * Ventana flotante de SB MODS V4 · DEMO.
 *
 * TODO lo que hace este panel es SIMULADO y local: no hay conexión a ningún juego,
 * no hay internet y no se modifica nada fuera de esta app. La etiqueta
 * "SIMULACIÓN · NO CONECTADO AL JUEGO" es fija y no se puede ocultar.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.sbmods.demo.STOP"
        const val CHANNEL_ID = "sbmods_demo_overlay"
        const val NOTIF_ID = 4401

        @Volatile
        var running = false
    }

    // ---- Paleta SB MODS (negro, gris, violeta) ----
    private val cBg = Color.parseColor("#070707")
    private val cSurface = Color.parseColor("#131316")
    private val cSurface2 = Color.parseColor("#1B1B20")
    private val cBorder = Color.parseColor("#2A2A33")
    private val cViolet = Color.parseColor("#8B5CF6")
    private val cVioletDim = Color.parseColor("#4C3A8A")
    private val cText = Color.parseColor("#F2F2F5")
    private val cMuted = Color.parseColor("#9A9AA5")
    private val cAmber = Color.parseColor("#FBBF24")
    private val cGreen = Color.parseColor("#34D399")

    private val pages = listOf(
        "INICIO", "DINERO", "MONEDAS", "CARROS", "CAMBIAR ID",
        "TIENDA VIP", "DESBLOQUEAR", "CUENTAS", "AJUSTES"
    )

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("sbmods_demo", MODE_PRIVATE) }

    private var bubble: View? = null
    private var panel: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var content: LinearLayout? = null
    private val chips = mutableListOf<TextView>()
    private var current = "INICIO"
    private var large = false

    // Estado de ejemplo (solo en memoria, todo ficticio)
    private var demoMoney = 0L
    private var demoCoins = 0L
    private var demoId = "DEMO-0000"
    private val vipActive = mutableSetOf<String>()
    private val unlocked = mutableSetOf<String>()
    private val addedCars = mutableSetOf<String>()

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (bubble == null && panel == null) showBubble()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeBubble()
        removePanel()
        running = false
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Ventana flotante DEMO", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(): Notification {
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("SB MODS V4 · DEMO")
            .setContentText("Ventana flotante de simulación activa")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat), "Cerrar", stopPi
                ).build()
            )
            .build()
    }

    // ------------------------------------------------------------------ utilidades UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun roundBg(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun baseParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun addWindow(v: View, lp: WindowManager.LayoutParams): Boolean = try {
        wm.addView(v, lp)
        true
    } catch (e: Exception) {
        false
    }

    private fun updateWindow(v: View, lp: WindowManager.LayoutParams) {
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
            // la vista ya no está en pantalla
        }
    }

    private fun clamp(lp: WindowManager.LayoutParams, v: View) {
        val w = if (v.width > 0) v.width else if (lp.width > 0) lp.width else dp(60)
        val h = if (v.height > 0) v.height else if (lp.height > 0) lp.height else dp(70)
        lp.x = lp.x.coerceIn(0, max(0, screenW() - w))
        lp.y = lp.y.coerceIn(0, max(0, screenH() - h))
    }

    /** Arrastre: mueve la ventana; si casi no se movió, cuenta como toque. */
    private fun attachDrag(
        handle: View, target: View, lp: WindowManager.LayoutParams,
        onSaved: () -> Unit, onTap: (() -> Unit)?
    ) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = e.rawX; downY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        clamp(lp, target)
                        updateWindow(target, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) onSaved() else onTap?.invoke()
                    true
                }
                else -> true
            }
        }
    }

    // ------------------------------------------------------------------ botón flotante

    private fun showBubble() {
        removePanel()
        if (bubble != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val circle = tv("SB", 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(cBg)
                setStroke(dp(2), cViolet)
            }
        }
        root.addView(circle, LinearLayout.LayoutParams(dp(52), dp(52)))
        val tag = tv("DEMO", 9f, Color.BLACK, true).apply {
            background = roundBg(cAmber, 6)
            setPadding(dp(6), dp(1), dp(6), dp(1))
        }
        root.addView(tag, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(3) })

        val lp = baseParams(WRAP, WRAP).apply {
            x = prefs.getInt("bx", dp(8))
            y = prefs.getInt("by", dp(240))
        }
        attachDrag(root, root, lp, {
            prefs.edit().putInt("bx", lp.x).putInt("by", lp.y).apply()
        }) { showPanel() }
        if (addWindow(root, lp)) {
            bubble = root
            root.post { clamp(lp, root); updateWindow(root, lp) }
        } else {
            stopSelf()
        }
    }

    private fun removeBubble() {
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        bubble = null
    }

    // ------------------------------------------------------------------ ventana principal

    private fun panelSize(): Pair<Int, Int> {
        val w = min(dp(if (large) 340 else 300), screenW() - dp(16))
        val h = min(dp(if (large) 560 else 400), screenH() - dp(100))
        return Pair(w, h)
    }

    private fun showPanel() {
        removeBubble()
        if (panel != null) return
        large = prefs.getBoolean("large", false)
        val (w, h) = panelSize()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(cBg, 18, cVioletDim)
        }

        val lp = baseParams(w, h).apply {
            x = prefs.getInt("px", dp(16))
            y = prefs.getInt("py", dp(120))
        }

        // Encabezado (también sirve para arrastrar)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(6), dp(8))
            background = roundBg(cSurface, 18)
        }
        header.addView(
            tv("SB", 12f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = roundBg(cViolet, 8)
            }, LinearLayout.LayoutParams(dp(28), dp(28))
        )
        header.addView(
            tv("SB MODS V4", 14f, cText, true).apply { setPadding(dp(8), 0, 0, 0) },
            LinearLayout.LayoutParams(WRAP, WRAP)
        )
        header.addView(
            tv("DEMO", 9f, Color.BLACK, true).apply {
                background = roundBg(cAmber, 6)
                setPadding(dp(6), dp(1), dp(6), dp(1))
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(6) }
        )
        header.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(headerButton("—") { minimizePanel() })
        header.addView(headerButton("⤢") { toggleSize() })
        header.addView(headerButton("✕") { stopSelf() })
        root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        // Navegación
        chips.clear()
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(6))
        }
        for (p in pages) {
            val chip = tv(p, 11f, cMuted, true).apply {
                setPadding(dp(12), dp(7), dp(12), dp(7))
                isClickable = true
                setOnClickListener {
                    current = p
                    renderPage()
                }
            }
            chips.add(chip)
            nav.addView(chip, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(6) })
        }
        root.addView(
            HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(nav)
            }, LinearLayout.LayoutParams(MATCH, WRAP)
        )

        // Contenido
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(10))
        }
        content = col
        root.addView(
            ScrollView(this).apply { addView(col) },
            LinearLayout.LayoutParams(MATCH, 0, 1f)
        )

        // Etiqueta fija de simulación (no se puede ocultar ni minimizar dentro de la ventana)
        root.addView(
            tv("SIMULACIÓN · NO CONECTADO AL JUEGO", 11f, Color.BLACK, true).apply {
                gravity = Gravity.CENTER
                setBackgroundColor(cAmber)
                setPadding(dp(8), dp(7), dp(8), dp(7))
            }, LinearLayout.LayoutParams(MATCH, WRAP)
        )

        attachDrag(header, root, lp, {
            prefs.edit().putInt("px", lp.x).putInt("py", lp.y).apply()
        }, null)

        if (!addWindow(root, lp)) {
            stopSelf()
            return
        }
        panel = root
        panelLp = lp
        current = "INICIO"
        renderPage()

        val targetAlpha = prefs.getInt("alpha", 100) / 100f
        root.alpha = 0f
        root.scaleX = 0.92f
        root.scaleY = 0.92f
        root.animate().alpha(targetAlpha).scaleX(1f).scaleY(1f).setDuration(180).start()
        root.post { clamp(lp, root); updateWindow(root, lp) }
    }

    private fun headerButton(label: String, onClick: () -> Unit): TextView =
        tv(label, 16f, cText, true).apply {
            gravity = Gravity.CENTER
            isClickable = true
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(34))
        }

    private fun minimizePanel() {
        val p = panel ?: return
        p.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150).withEndAction {
            removePanel()
            showBubble()
        }.start()
    }

    private fun toggleSize() {
        large = !large
        prefs.edit().putBoolean("large", large).apply()
        applySize()
    }

    private fun applySize() {
        val p = panel ?: return
        val lp = panelLp ?: return
        val (w, h) = panelSize()
        lp.width = w
        lp.height = h
        clamp(lp, p)
        updateWindow(p, lp)
    }

    private fun removePanel() {
        panel?.let {
            it.animate().cancel()
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        panel = null
        panelLp = null
        content = null
        chips.clear()
    }

    // ------------------------------------------------------------------ páginas

    private fun renderPage() {
        val col = content ?: return
        col.removeAllViews()
        pages.forEachIndexed { i, name ->
            val sel = name == current
            chips.getOrNull(i)?.apply {
                background = roundBg(if (sel) cViolet else cSurface2, 14, if (sel) null else cBorder)
                setTextColor(if (sel) Color.WHITE else cMuted)
            }
        }
        when (current) {
            "INICIO" -> pageInicio(col)
            "DINERO" -> pageAmount(
                col, "AGREGAR DINERO", "Saldo de ejemplo",
                listOf(1_000L, 10_000L, 100_000L, 1_000_000L), { demoMoney }) { demoMoney += it }
            "MONEDAS" -> pageAmount(
                col, "AGREGAR MONEDAS", "Monedas de ejemplo",
                listOf(10L, 100L, 1_000L, 10_000L), { demoCoins }) { demoCoins += it }
            "CARROS" -> pageCarros(col)
            "CAMBIAR ID" -> pageId(col)
            "TIENDA VIP" -> pageVip(col)
            "DESBLOQUEAR" -> pageUnlock(col)
            "CUENTAS" -> pageCuentas(col)
            "AJUSTES" -> pageAjustes(col)
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = roundBg(cSurface, 12, cBorder)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) }
    }

    private fun pill(text: String, filled: Boolean = true): TextView =
        tv(text, 12f, if (filled) Color.WHITE else cText, true).apply {
            gravity = Gravity.CENTER
            background = roundBg(if (filled) cViolet else cSurface2, 10, if (filled) null else cBorder)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            isClickable = true
        }

    private fun kv(k: String, v: String, vColor: Int = cText): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(3), 0, dp(3))
        addView(tv(k, 11f, cMuted, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        addView(tv(v, 11f, vColor, true))
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }

    /** Simula una acción con una barrita de progreso en el propio botón. */
    private fun simulate(btn: TextView, idle: String, onDone: () -> Unit) {
        if (!btn.isEnabled) return
        btn.isEnabled = false
        var p = 0
        val step = object : Runnable {
            override fun run() {
                p += 20
                if (p >= 100) {
                    btn.text = "✔ SIMULADO"
                    onDone()
                    handler.postDelayed({
                        btn.text = idle
                        btn.isEnabled = true
                    }, 1200)
                } else {
                    btn.text = "SIMULANDO $p%"
                    handler.postDelayed(this, 180)
                }
            }
        }
        handler.post(step)
    }

    private fun fmt(n: Long) = "%,d".format(n)

    private fun pageInicio(col: LinearLayout) {
        val c = card()
        c.addView(tv("ESTADO DEL SISTEMA", 12f, cText, true))
        c.addView(kv("MOTOR", "SIMULADO", cAmber))
        c.addView(kv("JUEGO VINCULADO", "NO", cAmber))
        c.addView(kv("ESTADO", "DEMO", cAmber))
        c.addView(kv("PERMISOS", "SOLO VENTANA FLOTANTE"))
        c.addView(kv("INTERNET", "SIN ACCESO", cGreen))
        col.addView(c)

        val info = card()
        info.addView(
            tv(
                "Todo lo que ves aquí es una simulación visual. Ningún botón se conecta a un " +
                    "juego ni modifica cuentas, dinero, coches o datos reales.",
                11f, cMuted
            )
        )
        info.addView(tv("CANAL @MOMKEY_SB", 11f, cViolet, true), lp(8))
        col.addView(info)
    }

    private fun pageAmount(
        col: LinearLayout, title: String, balLabel: String,
        amounts: List<Long>, getBal: () -> Long, add: (Long) -> Unit
    ) {
        val c = card()
        c.addView(tv(title, 12f, cText, true))
        val bal = tv("$balLabel: ${fmt(getBal())}", 12f, cViolet, true)
        c.addView(bal, lp(4))
        c.addView(tv("Valor ficticio, solo dentro de esta demo.", 10f, cMuted), lp(2))
        col.addView(c)
        for (a in amounts) {
            val idle = "+ ${fmt(a)}  (SIMULADO)"
            val b = pill(idle, false)
            b.setOnClickListener {
                simulate(b, idle) {
                    add(a)
                    bal.text = "$balLabel: ${fmt(getBal())}"
                }
            }
            col.addView(b, lp(6))
        }
    }

    private fun pageCarros(col: LinearLayout) {
        col.addView(tv("AGREGAR CARROS", 12f, cText, true))
        for (name in listOf("Coche de ejemplo A", "Coche de ejemplo B", "Coche de ejemplo C", "Coche de ejemplo D")) {
            val c = card()
            c.layoutParams = lp(8)
            val state = tv(if (name in addedCars) "EN GARAJE DE EJEMPLO" else "No agregado", 10f,
                if (name in addedCars) cGreen else cMuted, true)
            c.addView(tv(name, 12f, cText, true))
            c.addView(state)
            val idle = "AGREGAR (SIMULADO)"
            val b = pill(idle)
            b.setOnClickListener {
                simulate(b, idle) {
                    addedCars.add(name)
                    state.text = "EN GARAJE DE EJEMPLO"
                    state.setTextColor(cGreen)
                }
            }
            c.addView(b, lp(8))
            col.addView(c)
        }
    }

    private fun pageId(col: LinearLayout) {
        val c = card()
        c.addView(tv("CAMBIAR ID", 12f, cText, true))
        val idView = tv("ID de ejemplo: $demoId", 13f, cViolet, true)
        c.addView(idView, lp(6))
        c.addView(tv("No se pide ni se guarda ningún ID real.", 10f, cMuted), lp(2))
        val idle = "GENERAR ID DE EJEMPLO"
        val b = pill(idle)
        b.setOnClickListener {
            simulate(b, idle) {
                demoId = "DEMO-" + Random.nextInt(1000, 9999)
                idView.text = "ID de ejemplo: $demoId"
            }
        }
        c.addView(b, lp(10))
        col.addView(c)
    }

    private fun pageVip(col: LinearLayout) {
        col.addView(tv("TIENDA VIP", 12f, cText, true))
        for (name in listOf("VIP DEMO 1", "VIP DEMO 2", "VIP DEMO 3")) {
            val c = card()
            c.layoutParams = lp(8)
            val state = tv(if (name in vipActive) "ACTIVO (SIMULADO)" else "Inactivo", 10f,
                if (name in vipActive) cGreen else cMuted, true)
            c.addView(tv(name, 12f, cText, true))
            c.addView(state)
            val idle = "ACTIVAR (SIMULADO)"
            val b = pill(idle)
            b.setOnClickListener {
                simulate(b, idle) {
                    vipActive.add(name)
                    state.text = "ACTIVO (SIMULADO)"
                    state.setTextColor(cGreen)
                }
            }
            c.addView(b, lp(8))
            col.addView(c)
        }
    }

    private fun pageUnlock(col: LinearLayout) {
        col.addView(tv("DESBLOQUEAR CARROS", 12f, cText, true))
        for (name in listOf("Coche bloqueado 1", "Coche bloqueado 2", "Coche bloqueado 3", "Coche bloqueado 4")) {
            val c = card()
            c.layoutParams = lp(8)
            val open = name in unlocked
            val state = tv(if (open) "🔓 DESBLOQUEADO (SIMULADO)" else "🔒 Bloqueado", 10f,
                if (open) cGreen else cMuted, true)
            c.addView(tv(name, 12f, cText, true))
            c.addView(state)
            val idle = "DESBLOQUEAR (SIMULADO)"
            val b = pill(idle)
            b.setOnClickListener {
                simulate(b, idle) {
                    unlocked.add(name)
                    state.text = "🔓 DESBLOQUEADO (SIMULADO)"
                    state.setTextColor(cGreen)
                }
            }
            c.addView(b, lp(8))
            col.addView(c)
        }
    }

    private fun pageCuentas(col: LinearLayout) {
        col.addView(tv("CUENTAS", 12f, cText, true))
        col.addView(
            tv("Lista de ejemplo. No se piden ni se guardan datos de cuentas reales.", 10f, cMuted),
            lp(4)
        )
        for (name in listOf("cuenta_ejemplo_1", "cuenta_ejemplo_2", "cuenta_ejemplo_3")) {
            val c = card()
            c.layoutParams = lp(8)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(tv(name, 12f, cText, true), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(
                tv("EJEMPLO", 9f, Color.BLACK, true).apply {
                    background = roundBg(cAmber, 6)
                    setPadding(dp(6), dp(1), dp(6), dp(1))
                }
            )
            c.addView(row)
            col.addView(c)
        }
    }

    /** Estos ajustes sí son reales: tamaño, transparencia y posición de la ventana. */
    private fun pageAjustes(col: LinearLayout) {
        val c = card()
        c.addView(tv("AJUSTES DE LA VENTANA", 12f, cText, true))

        val sizeBtn = pill(if (large) "TAMAÑO: GRANDE" else "TAMAÑO: COMPACTO", false)
        sizeBtn.setOnClickListener {
            toggleSize()
            sizeBtn.text = if (large) "TAMAÑO: GRANDE" else "TAMAÑO: COMPACTO"
        }
        c.addView(sizeBtn, lp(8))

        val alphaPct = prefs.getInt("alpha", 100)
        val alphaLabel = tv("Transparencia: $alphaPct%", 11f, cMuted, true)
        c.addView(alphaLabel, lp(10))
        val seek = SeekBar(this).apply {
            max = 60 // 40..100
            progress = alphaPct - 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                    val pct = 40 + value
                    alphaLabel.text = "Transparencia: $pct%"
                    panel?.alpha = pct / 100f
                    if (fromUser) prefs.edit().putInt("alpha", pct).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        c.addView(seek, lp(4))

        val reset = pill("RESTABLECER POSICIÓN", false)
        reset.setOnClickListener {
            prefs.edit().remove("px").remove("py").remove("bx").remove("by").apply()
            panelLp?.let { l ->
                l.x = dp(16); l.y = dp(120)
                panel?.let { p -> clamp(l, p); updateWindow(p, l) }
            }
        }
        c.addView(reset, lp(10))

        val close = pill("CERRAR VENTANA FLOTANTE")
        close.setOnClickListener { stopSelf() }
        c.addView(close, lp(10))
        col.addView(c)

        col.addView(
            tv("La etiqueta de SIMULACIÓN es fija y no se puede quitar.", 10f, cMuted),
            lp(4)
        )
    }
}
