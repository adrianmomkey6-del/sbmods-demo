package com.sbmods.demo

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Pantalla principal de SB MODS V4 · DEMO.
 * Es una app de SIMULACIÓN visual: no se conecta a ningún juego, no tiene internet
 * y no modifica nada fuera de sí misma.
 */
class MainActivity : Activity() {

    private val cBg = Color.parseColor("#070707")
    private val cSurface = Color.parseColor("#131316")
    private val cBorder = Color.parseColor("#2A2A33")
    private val cViolet = Color.parseColor("#8B5CF6")
    private val cText = Color.parseColor("#F2F2F5")
    private val cMuted = Color.parseColor("#9A9AA5")
    private val cAmber = Color.parseColor("#FBBF24")

    private lateinit var statusText: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun bg(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit): TextView =
        tv(text, 14f, if (filled) Color.WHITE else cText, true).apply {
            gravity = Gravity.CENTER
            background = bg(if (filled) cViolet else cSurface, 12, if (filled) null else cBorder)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            isClickable = true
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }

        col.addView(tv("SB MODS V4", 28f, cText, true))

        val chip = tv("DEMO", 12f, Color.BLACK, true).apply {
            background = bg(cAmber, 8)
            setPadding(dp(10), dp(3), dp(10), dp(3))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        col.addView(chip)

        val banner = tv("SIMULACIÓN · NO CONECTADO AL JUEGO", 13f, Color.BLACK, true).apply {
            gravity = Gravity.CENTER
            background = bg(cAmber, 10)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(18) }
        }
        col.addView(banner)

        col.addView(
            tv(
                "Esta app es un proyecto visual de demostración. Muestra una ventana flotante " +
                    "con un panel de ejemplo sobre otras apps. No se conecta a ningún juego, " +
                    "no tiene acceso a internet, no pide cuentas ni modifica nada.",
                14f, cMuted
            ).apply { setPadding(0, dp(16), 0, dp(8)) }
        )

        statusText = tv("", 13f, cText, true).apply {
            background = bg(cSurface, 12, cBorder)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        col.addView(statusText)

        col.addView(button("1 · CONCEDER PERMISO DE SUPERPOSICIÓN", false) { openOverlaySettings() })
        col.addView(button("2 · PERMITIR NOTIFICACIONES (opcional)", false) { askNotifications() })
        col.addView(button("3 · ACTIVAR VENTANA FLOTANTE", true) { startOverlay() })
        col.addView(button("DETENER VENTANA FLOTANTE", false) { stopOverlay() })

        col.addView(
            tv("Canal @MOMKEY_SB", 12f, cMuted).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(24), 0, 0)
            }
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg)
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val perm = if (Settings.canDrawOverlays(this)) "CONCEDIDO" else "PENDIENTE"
        val run = if (OverlayService.running) "ACTIVA" else "APAGADA"
        statusText.text = "PERMISO DE SUPERPOSICIÓN: $perm\nVENTANA FLOTANTE: $run\nJUEGO VINCULADO: NO"
    }

    private fun openOverlaySettings() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "El permiso ya está concedido", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else {
            Toast.makeText(this, "No hace falta en esta versión de Android", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primero concede el permiso (paso 1)", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Ventana flotante activada. Abre otra app.", Toast.LENGTH_SHORT).show()
        refreshStatusDelayed()
        moveTaskToBack(true)
    }

    private fun stopOverlay() {
        startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        refreshStatusDelayed()
    }

    private fun refreshStatusDelayed() {
        statusText.postDelayed({ refreshStatus() }, 400)
    }
}
