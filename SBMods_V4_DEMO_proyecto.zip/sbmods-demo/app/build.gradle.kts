plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sbmods.demo"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sbmods.demo"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "4.0-demo"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sin dependencias externas a propósito: solo Android SDK + Kotlin stdlib.
